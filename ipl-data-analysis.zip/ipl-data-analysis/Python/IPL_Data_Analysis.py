# Works with the usual public IPL files: matches.csv and deliveries.csv.
# Drop both into ../Dataset/ (or change MATCHES_FILE / DELIVERIES_FILE below) and run this from the Python folder.

from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path.cwd()
# If running this .py from the Python folder, these paths work.
DATA_DIR = ROOT.parent / "Dataset"
MATCHES_FILE = DATA_DIR / "matches.csv"
DELIVERIES_FILE = DATA_DIR / "deliveries.csv"
OUTPUT_DIR = ROOT.parent / "Report" / "charts"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def find_col(df, candidates, required=True):
    """Return first matching column, case-insensitive."""
    lower = {str(c).strip().lower(): c for c in df.columns}
    for name in candidates:
        if name.lower() in lower:
            return lower[name.lower()]
    if required:
        raise ValueError(f"Could not find any of these columns: {candidates}. Found: {list(df.columns)}")
    return None

def load_data():
    if not MATCHES_FILE.exists() or not DELIVERIES_FILE.exists():
        raise FileNotFoundError(
            f"Please place matches.csv and deliveries.csv in {DATA_DIR}. "
            "Common public IPL datasets provide these two files."
        )
    matches = pd.read_csv(MATCHES_FILE)
    deliveries = pd.read_csv(DELIVERIES_FILE)
    return matches, deliveries

matches, deliveries = load_data()

# take a first look at the raw data
print("MATCHES - first 5 rows\n", matches.head(), "\n")
print("MATCHES - last 5 rows\n", matches.tail(), "\n")
print("Matches shape:", matches.shape)
print("Delivery shape:", deliveries.shape)
print("Match columns:", matches.columns.tolist())
print("Delivery columns:", deliveries.columns.tolist())
print("Match numerical columns:", matches.select_dtypes(include=np.number).columns.tolist())
print("Match categorical columns:", matches.select_dtypes(exclude=np.number).columns.tolist())

# cleaning
matches.columns = matches.columns.str.strip()
deliveries.columns = deliveries.columns.str.strip()
matches = matches.drop_duplicates().copy()
deliveries = deliveries.drop_duplicates().copy()

# column names differ between dataset versions, so look them up instead of hardcoding
season_col = find_col(matches, ["season", "year"])
date_col = find_col(matches, ["date", "match_date"], required=False)
match_id_col = find_col(matches, ["id", "match_id"], required=False)
winner_col = find_col(matches, ["winner"], required=False)
team1_col = find_col(matches, ["team1"], required=False)
team2_col = find_col(matches, ["team2"], required=False)
toss_winner_col = find_col(matches, ["toss_winner"], required=False)
toss_decision_col = find_col(matches, ["toss_decision"], required=False)
venue_col = find_col(matches, ["venue"], required=False)
city_col = find_col(matches, ["city"], required=False)
pom_col = find_col(matches, ["player_of_match", "player of match"], required=False)
result_col = find_col(matches, ["result"], required=False)
runs_margin_col = find_col(matches, ["result_margin", "win_by_runs"], required=False)
target_overs_col = find_col(matches, ["target_overs"], required=False)

if date_col:
    matches[date_col] = pd.to_datetime(matches[date_col], errors="coerce")

# tidy up whitespace and unify the old/new team names
team_map = {
    "Delhi Daredevils": "Delhi Capitals",
    "Deccan Chargers": "Deccan Chargers",
    "Kings XI Punjab": "Punjab Kings",
    "Royal Challengers Bangalore": "Royal Challengers Bengaluru",
}
for c in [team1_col, team2_col, winner_col, toss_winner_col]:
    if c:
        matches[c] = matches[c].astype("string").str.strip().replace(team_map)

# leave unknowns as missing, don't make up winners
for c in [venue_col, city_col, pom_col, winner_col, toss_winner_col, toss_decision_col]:
    if c:
        matches[c] = matches[c].replace(["", "NA", "N/A", "null", "None"], np.nan)

print("\nMissing values in matches:\n", matches.isna().sum().sort_values(ascending=False))
print("\nMissing values in deliveries:\n", deliveries.isna().sum().sort_values(ascending=False))
print("Duplicate rows after cleaning:", matches.duplicated().sum(), deliveries.duplicated().sum())
print("Unique seasons:", sorted(matches[season_col].dropna().astype(str).unique().tolist()))
for c in [team1_col, team2_col, winner_col, toss_winner_col, venue_col, toss_decision_col]:
    if c:
        print(f"Unique values in {c}:", matches[c].nunique())

# same lookup for the deliveries columns
d_match_id = find_col(deliveries, ["match_id", "id"])
d_batting_team = find_col(deliveries, ["batting_team"])
d_bowling_team = find_col(deliveries, ["bowling_team"])
d_batter = find_col(deliveries, ["batter", " batsman", "batsman"])
d_bowler = find_col(deliveries, ["bowler"])
d_batsman_runs = find_col(deliveries, ["batsman_runs", "runs_scored"])
d_total_runs = find_col(deliveries, ["total_runs"])
d_extra_runs = find_col(deliveries, ["extra_runs"], required=False)
d_player_dismissed = find_col(deliveries, ["player_dismissed"], required=False)
d_dismissal_kind = find_col(deliveries, ["dismissal_kind"], required=False)
d_over = find_col(deliveries, ["over"], required=False)
d_ball = find_col(deliveries, ["ball"], required=False)

for c in [d_batting_team, d_bowling_team]:
    deliveries[c] = deliveries[c].astype("string").str.strip().replace(team_map)
for c in [d_batsman_runs, d_total_runs, d_extra_runs]:
    if c:
        deliveries[c] = pd.to_numeric(deliveries[c], errors="coerce").fillna(0)

# the actual analysis
total_matches = matches[match_id_col].nunique() if match_id_col else len(matches)
print("\nTOTAL MATCHES:", total_matches)

season_matches = matches.groupby(season_col)[match_id_col].nunique() if match_id_col else matches.groupby(season_col).size()
print("\nMatches per season:\n", season_matches.sort_index())

if winner_col:
    team_wins = matches[winner_col].dropna().value_counts()
    print("\nWins by team:\n", team_wins)
    print("Highest wins:", team_wins.idxmax() if len(team_wins) else "N/A")
    print("Lowest wins (among teams with at least one win):", team_wins.idxmin() if len(team_wins) else "N/A")
else:
    team_wins = pd.Series(dtype=int)

if pom_col:
    pom_awards = matches[pom_col].dropna().value_counts()
    print("\nMost Player of Match awards:\n", pom_awards.head(10))
else:
    pom_awards = pd.Series(dtype=int)

if venue_col:
    venue_counts = matches[venue_col].fillna("Unknown").value_counts()
    print("\nMost frequent venue:\n", venue_counts.head(10))
else:
    venue_counts = pd.Series(dtype=int)

if toss_decision_col:
    print("\nToss decisions:\n", matches[toss_decision_col].value_counts(dropna=False))

if toss_winner_col and winner_col:
    valid_toss = matches.dropna(subset=[toss_winner_col, winner_col])
    toss_win_pct = (valid_toss[toss_winner_col] == valid_toss[winner_col]).mean() * 100 if len(valid_toss) else np.nan
    print(f"\nPercentage of matches where toss winner also won: {toss_win_pct:.2f}% ({len(valid_toss)} valid matches)")

if runs_margin_col:
    print("\nHighest win margin by runs:", pd.to_numeric(matches[runs_margin_col], errors="coerce").max())
wickets_margin_col = find_col(matches, ["result_margin_wickets", "win_by_wickets"], required=False)
if wickets_margin_col:
    print("Highest win margin by wickets:", pd.to_numeric(matches[wickets_margin_col], errors="coerce").max())

# Batter totals
batter_runs = deliveries.groupby(d_batter)[d_batsman_runs].sum().sort_values(ascending=False)
print("\nTop 10 batsmen by runs:\n", batter_runs.head(10))

# Wickets: exclude run out, retired hurt, obstructing the field, and non-batter dismissals
if d_player_dismissed and d_dismissal_kind:
    valid_dismissals = {"bowled", "caught", "caught and bowled", "lbw", "stumped", "hit wicket", "hit the ball twice", "handled the ball"}
    wkts = deliveries[
        deliveries[d_player_dismissed].notna()
        & deliveries[d_dismissal_kind].astype(str).str.lower().isin(valid_dismissals)
    ]
    bowler_wickets = wkts.groupby(d_bowler)[d_player_dismissed].count().sort_values(ascending=False)
else:
    bowler_wickets = pd.Series(dtype=int)
print("\nTop 10 bowlers by credited wickets:\n", bowler_wickets.head(10))

# Season-level run/wicket totals by joining match season to delivery match id.
if match_id_col:
    season_lookup = matches[[match_id_col, season_col]].drop_duplicates().rename(columns={match_id_col: d_match_id})
    ball_season = deliveries.merge(season_lookup, on=d_match_id, how="left")
else:
    ball_season = deliveries.copy()
    ball_season[season_col] = np.nan
season_runs = ball_season.groupby(season_col)[d_total_runs].sum().sort_index()
print("\nSeason total runs:\n", season_runs)

if d_player_dismissed:
    season_wickets = ball_season[ball_season[d_player_dismissed].notna()].groupby(season_col)[d_player_dismissed].count().sort_index()
else:
    season_wickets = pd.Series(dtype=int)
print("\nSeason total dismissals (not necessarily bowler-credited wickets):\n", season_wickets)

runs_per_match = deliveries.groupby(d_match_id)[d_total_runs].sum()
print("Average runs per match (all innings combined):", round(runs_per_match.mean(), 2))

team_runs = deliveries.groupby(d_batting_team)[d_total_runs].sum().sort_values(ascending=False)
team_match_innings = deliveries.groupby([d_match_id, d_batting_team])[d_total_runs].sum()
team_avg_runs = team_match_innings.groupby(level=1).mean().sort_values(ascending=False)
print("\nTeam total runs:\n", team_runs)
print("\nTeam average runs per innings:\n", team_avg_runs)

# Season-wise wins by team
if winner_col:
    season_team_wins = matches.dropna(subset=[winner_col]).groupby([season_col, winner_col]).size().rename("Wins").reset_index()
    print("\nSeason-wise team wins:\n", season_team_wins.to_string(index=False))
else:
    season_team_wins = pd.DataFrame()

# Most successful venue per team, based on match wins at a venue.
if venue_col and winner_col:
    venue_team = matches.dropna(subset=[venue_col, winner_col]).groupby([winner_col, venue_col]).size().rename("Wins").reset_index()
    best_venue_per_team = venue_team.loc[venue_team.groupby(winner_col)["Wins"].idxmax()].sort_values(winner_col)
    print("\nMost wins by venue for each winning team:\n", best_venue_per_team.to_string(index=False))
else:
    best_venue_per_team = pd.DataFrame()

# charts
sns.set_theme(style="whitegrid")
def save_plot(filename):
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / filename, dpi=160, bbox_inches="tight")
    plt.show()
    plt.close()

plt.figure(figsize=(12, 5))
season_matches.sort_index().plot(kind="bar")
plt.title("Matches Played by Season"); plt.xlabel("Season"); plt.ylabel("Matches")
save_plot("01_matches_by_season.png")

if len(team_wins):
    plt.figure(figsize=(12, 6)); team_wins.sort_values().plot(kind="barh")
    plt.title("Matches Won by Team"); plt.xlabel("Wins"); plt.ylabel("Team")
    save_plot("02_team_wins.png")

plt.figure(figsize=(10, 6)); batter_runs.head(10).sort_values().plot(kind="barh")
plt.title("Top 10 Run Scorers"); plt.xlabel("Runs"); plt.ylabel("Batter")
save_plot("03_top_batsmen.png")

if len(bowler_wickets):
    plt.figure(figsize=(10, 6)); bowler_wickets.head(10).sort_values().plot(kind="barh")
    plt.title("Top 10 Wicket Takers"); plt.xlabel("Credited wickets"); plt.ylabel("Bowler")
    save_plot("04_top_bowlers.png")

if len(pom_awards):
    plt.figure(figsize=(12, 6)); pom_awards.head(10).sort_values().plot(kind="barh")
    plt.title("Player of the Match Awards (Top 10)"); plt.xlabel("Awards"); plt.ylabel("Player")
    save_plot("05_player_of_match.png")

if toss_decision_col:
    toss_counts = matches[toss_decision_col].value_counts()
    plt.figure(figsize=(6, 6)); toss_counts.plot(kind="pie", autopct="%1.1f%%", startangle=90)
    plt.ylabel(""); plt.title("Toss Decision Distribution")
    save_plot("06_toss_decisions.png")

if toss_winner_col and winner_col:
    toss_match = matches.dropna(subset=[toss_winner_col, winner_col]).assign(
        TossWinnerWon=lambda x: x[toss_winner_col] == x[winner_col]
    )["TossWinnerWon"].value_counts().rename(index={True:"Toss winner won", False:"Toss winner lost"})
    plt.figure(figsize=(7, 5)); toss_match.plot(kind="bar")
    plt.title("Match Outcome After Winning Toss"); plt.ylabel("Matches"); plt.xlabel("")
    save_plot("07_toss_vs_match.png")

plt.figure(figsize=(12, 5)); season_runs.plot(marker="o")
plt.title("Season-wise Total Runs"); plt.xlabel("Season"); plt.ylabel("Runs")
save_plot("08_season_runs.png")

if len(season_wickets):
    plt.figure(figsize=(12, 5)); season_wickets.plot(marker="o")
    plt.title("Season-wise Total Dismissals"); plt.xlabel("Season"); plt.ylabel("Dismissals")
    save_plot("09_season_wickets.png")

plt.figure(figsize=(9, 5)); deliveries[d_total_runs].plot(kind="hist", bins=20, edgecolor="black")
plt.title("Distribution of Runs per Delivery"); plt.xlabel("Runs on delivery")
save_plot("10_runs_histogram.png")

plt.figure(figsize=(12, 5)); team_runs.head(12).sort_values().plot(kind="barh")
plt.title("Team Performance Comparison (Total Runs)"); plt.xlabel("Total runs")
save_plot("11_team_runs.png")

if len(venue_counts):
    plt.figure(figsize=(12, 6)); venue_counts.head(15).sort_values().plot(kind="barh")
    plt.title("Venue-wise Match Count (Top 15)"); plt.xlabel("Matches")
    save_plot("12_venue_counts.png")

plt.figure(figsize=(8, 5))
if d_player_dismissed:
    runs_per_delivery = deliveries.groupby(d_match_id)[d_total_runs].sum()
    wickets_per_match = deliveries[deliveries[d_player_dismissed].notna()].groupby(d_match_id)[d_player_dismissed].count()
    scatter = pd.concat([runs_per_delivery.rename("Runs"), wickets_per_match.rename("Wickets")], axis=1).fillna(0)
    sns.scatterplot(data=scatter, x="Wickets", y="Runs", alpha=.6)
else:
    sns.scatterplot(data=deliveries, x=d_batsman_runs, y=d_total_runs, alpha=.4)
plt.title("Runs vs Wickets"); save_plot("13_runs_vs_wickets.png")

numeric = deliveries.select_dtypes(include=np.number)
if numeric.shape[1] >= 2:
    plt.figure(figsize=(10, 7)); sns.heatmap(numeric.corr(numeric_only=True), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Delivery Numeric Feature Correlation Heatmap")
    save_plot("14_correlation_heatmap.png")

# save the cleaned data
matches.to_csv(DATA_DIR / "IPL_Matches_Cleaned.csv", index=False)
deliveries.to_csv(DATA_DIR / "IPL_Deliveries_Cleaned.csv", index=False)

# one Excel file with every summary table, handy for review or as a Power BI source
excel_path = DATA_DIR / "IPL_Analysis_Results.xlsx"
with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
    matches.to_excel(writer, sheet_name="Cleaned_Matches", index=False)
    deliveries.to_excel(writer, sheet_name="Cleaned_Deliveries", index=False)
    season_matches.rename("Matches").reset_index().to_excel(writer, sheet_name="Matches_by_Season", index=False)
    team_wins.rename("Wins").reset_index().to_excel(writer, sheet_name="Team_Wins", index=False)
    batter_runs.head(10).rename("Runs").reset_index().to_excel(writer, sheet_name="Top_Batsmen", index=False)
    bowler_wickets.head(10).rename("Wickets").reset_index().to_excel(writer, sheet_name="Top_Bowlers", index=False)
    pom_awards.head(10).rename("Awards").reset_index().to_excel(writer, sheet_name="Player_of_Match", index=False)
    season_runs.rename("Total_Runs").reset_index().to_excel(writer, sheet_name="Season_Runs", index=False)
    team_avg_runs.rename("Avg_Runs_Per_Innings").reset_index().to_excel(writer, sheet_name="Team_Avg_Runs", index=False)
print(f"\nAnalysis complete. Charts: {OUTPUT_DIR}; Excel results: {excel_path}")
